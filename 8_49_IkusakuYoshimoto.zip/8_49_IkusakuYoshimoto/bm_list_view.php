<?php
require "funcs.php";

//1.  DB接続します
$pdo = db_conn();

//２．データ取得SQL作成
$stmt = $pdo->prepare("SELECT * FROM gs_bm_table");
$status = $stmt->execute();

//３．データ表示
$view="";

$url = $result['website_url'];
console.log($url);

if($status==false) {
    //execute（SQL実行時にエラーがある場合）
  $error = $stmt->errorInfo();
  exit("ErrorQuery:".$error[2]);

}else{
  //Selectデータの数だけ自動でループしてくれる
  //FETCH_ASSOC=http://php.net/manual/ja/pdostatement.fetch.php
  while( $result = $stmt->fetch(PDO::FETCH_ASSOC)){ 
   
//以下をtabelタグの中に入れる
  $view .= "<tr>";

      $view .= "<td>";
        $view .= '<a href="bm_update_view.php?id='.$result["id"].'">';
          $view .= $result['date'];
        $view .= '</a>';
      $view .= "</td>";
      $view .= "<td>";
      $view .= '<a href="bm_update_view.php?id='.$result["id"].'">';
        $view .= $result['mountain_name'];
      $view .= '</a>';
    $view .= "</td>";
    $view .= "<td>";
        $view .= '<a href="bm_update_view.php?id='.$result["id"].'">';
          $view .= $result['comment'];
        $view .= '</a>';
      $view .= "</td>";

      $view .= "<td>";
        $view .= '<a href="$result["website_url"]">●リンク</a>';
        $view .= '<a href="bm_update_view.php?id='.$result["id"].'">';
          $view .= $result["website_url"];
        $view .= '</a>';

        //外部サイトへのリンクを作りたかったが、結局作れず・・・

        // <a href="$result['website_url']">リンク</a>
        // <a href="$result['website_url']">'</a>;

         // echo $result['websites_url'];
        
      $view .= "</td>";


    $view .= "<td>";
    $view .= '<a href="delete.php?id='.$result["id"].'">';
    $view .= "✖️ 削除";
    $view .= "</a>"; 
    $view .= "</td>";

  $view .= "</tr>";   

  }
}

?>



<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>山行記録　一覧</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body id="main">


<div class="list_wrapper">

  <header>
      <div class="header_container">  
        <h1 class="list_heading">登録一覧</h1>
        <div>
            <a class="register_change_button" href="index.php">新規登録</a>
        </div>
      </div>
  </header>

  <!-- 登録一覧表 -->
  <table>
      <tr>
        <th class="date">登頂日</th>
        <th class="mountain_name">山名</th>
        <th class="comment">コメント</th>
        <th class="url">山小屋HP</th>
        <th class="delete_button">編集</th>
      </tr>
      <div><?=$view?></div>

  </table>

</div>


</body>
</html>