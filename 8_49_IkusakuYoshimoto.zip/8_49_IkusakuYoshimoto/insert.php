<?php

//POSTデータ取得（index.phpのフォームからデータを受け取る）
$date = $_POST["date"];
$mountain_name = $_POST["mountain_name"];
$comment = $_POST["comment"];
$website_url = $_POST["website_url"];


//2. DB接続する関数
require "funcs.php"; //これでfuncs.phpに書いた関数を呼び出す
$pdo = db_con();

//３．データ登録SQL作成
$stmt = $pdo->prepare("INSERT INTO gs_bm_table(id,date,mountain_name,comment,website_url)VALUES(NULL,:a1,:a2,:a3,:a4)");
$stmt->bindValue(':a1', $date, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
$stmt->bindValue(':a2', $mountain_name, PDO::PARAM_STR);  
$stmt->bindValue(':a3', $comment, PDO::PARAM_STR);
$stmt->bindValue(':a4', $website_url, PDO::PARAM_STR);
$status = $stmt->execute();

//４．データ登録処理後
if($status==false){
  //SQL実行時にエラーがある場合（エラーオブジェクト取得して表示）
  $error = $stmt->errorInfo();
  exit("ErrorMassage:".$error[2]);

}else{
  //５．index.phpへリダイレクト
  header('Location: index.php');
 
}


?>
