-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- ホスト: localhost:8889
-- 生成日時: 2020 年 6 月 18 日 22:43
-- サーバのバージョン： 5.7.26
-- PHP のバージョン: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `my_database`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_bm_table`
--

CREATE TABLE `gs_bm_table` (
  `id` int(12) NOT NULL,
  `date` date NOT NULL,
  `mountain_name` varchar(64) NOT NULL,
  `comment` text NOT NULL,
  `website_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `gs_bm_table`
--

INSERT INTO `gs_bm_table` (`id`, `date`, `mountain_name`, `comment`, `website_url`) VALUES
(8, '2011-08-16', '槍ヶ岳', '今回は上高地から一日で登った。\r\n夕方はピークも空いていたので、明日向かう穂高の方を眺めながら、のんびり過ごした。', 'https://www.yarigatake.co.jp/yarigatake/'),
(9, '2011-08-14', '北穂高岳', '南岳から眺める大キレット越しの北穂高岳は、北アルプスで一番カッコいい景色で、ようやく辿り着いた北穂高小屋のテラスは最高だった。\r\n流れる雲の間から見え隠れする常念岳を見つめる一時。\"', 'http://www.kitaho.co.jp/'),
(10, '2012-10-12', '剱岳', '事前に映画　「剱岳 点の記」 を観て、登るのが本当に楽しみだった。\r\n別山尾根は予想していたよりもホールドがしっかりしていたが、下山のヨコバイでは足が届かない場所があり、仕方なく鎖に全体重をかけることになった。\r\nこの日は天気が悪くて頂上から何も見えなかったが、翌日は快晴に恵まれて、紅葉に彩られた剱岳をしっかり目に焼き付けて、剱沢小屋を後にした。', 'http://home.384.jp/tsuruqi1/'),
(14, '2020-06-18', '筑波山', '標高は低いがなかなか楽しめる山だった。\r\n頂上からは僅かに富士山が見えた。', 'https://www.mt-tsukuba.com/'),
(15, '2020-06-18', '塔ノ岳', '近場の低山の中では登りやすくて眺めもいい、素晴らしい山。\r\n晴れていれば、頂上からは富士山が良く見える。', 'https://www.kankou-hadano.org/hadano_mountain/mountain_tnd.html'),
(16, '2020-06-19', '陣馬山', '近場の縦走路としては悪くない。\r\n帰りは藤野駅から。', '');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `gs_bm_table`
--
ALTER TABLE `gs_bm_table`
  ADD PRIMARY KEY (`id`);

--
-- ダンプしたテーブルのAUTO_INCREMENT
--

--
-- テーブルのAUTO_INCREMENT `gs_bm_table`
--
ALTER TABLE `gs_bm_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
