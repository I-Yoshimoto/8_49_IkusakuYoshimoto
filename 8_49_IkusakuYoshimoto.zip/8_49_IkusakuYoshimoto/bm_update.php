<?php
//1.POSTでデータを取得
$date = $_POST["date"];
$mountain_name = $_POST["mountain_name"];
$comment = $_POST["comment"];
$website_url = $_POST["website_url"];
$id = $_POST["id"];

//2.DB接続など
require "funcs.php";
$pdo = db_con();


//3.UPDATE gs_bm_table SET ....; で更新(bindValue)
//基本的にinsert.phpの処理の流れと同じ
$stmt = $pdo->prepare("UPDATE gs_bm_table SET date=:a1, mountain_name=:a2, comment=:a3, website_url=:a4 WHERE id=:id");
$stmt->bindValue(':a1', $date, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
$stmt->bindValue(':a2', $mountain_name, PDO::PARAM_STR);  
$stmt->bindValue(':a3', $comment, PDO::PARAM_STR);  
$stmt->bindValue(':a4', $website_url, PDO::PARAM_STR);  
$stmt->bindValue(':id', $id, PDO::PARAM_STR);
$status = $stmt->execute();

if($status==false) {
    //SQLエラー関数
  }else{

   //一覧ページへ戻す
   redirect('bm_list_view.php');
  }
?>